from django.shortcuts import render
from django.http import HttpResponse
from .models import account

# Create your views here.
def index(request):
    return render(request, 'index.html')

def login(request):
    return render(request, 'login.html')    

def add_user_form_submission(request):
    userid = request.POST['userid']
    username = request.POST['username']
    email = request.POST['email']
    password = request.POST['password']
    account_type = request.POST['account_type']

    account1 = account(userid=userid, username = username,  email=email, password=password, account_type=account_type)
    account1.save()

    print("hello worldsss")
    return render(request, 'login.html')